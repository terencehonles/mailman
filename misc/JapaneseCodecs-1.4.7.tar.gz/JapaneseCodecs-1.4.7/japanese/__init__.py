# Tamito KAJIYAMA <12 March 2000>
# $Id: __init__.py,v 1.2 2002/04/17 03:50:41 kajiyama Exp $ 

try:
    import japanese.aliases
except ImportError:
    pass
