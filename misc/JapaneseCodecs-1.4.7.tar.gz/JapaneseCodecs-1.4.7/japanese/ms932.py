# Tamito KAJIYAMA <2 March 2002>

from japanese.c.ms932 import *
