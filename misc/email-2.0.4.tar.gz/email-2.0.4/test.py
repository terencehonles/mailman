# Copyright (C) 2002 Python Software Foundation

"""A simple test runner, which sets up sys.path properly."""

import sys
import os
import unittest

sys.path[0:0] = ['email', 'test']

from test_email import *
unittest.main(defaultTest='suite')
