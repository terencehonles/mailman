#!/usr/bin/env python
# Chen Chien-Hsun, modified from Tamito KAJIYAMA's original code

from distutils.core import setup

setup (name = "KoreanCodecs",
       version = "1.0.0",
       description = "Korean Codecs for Python Unicode Support",
       author = "Chen Chien-Hsun",
       author_email = "frank63@ms5.hinet.net",
       url = "",
       py_modules = ['eucksx1001_kr',
                     'koreaneuc.__init__',
                     'koreaneuc.ksx10012utf1',
                     'koreaneuc.ksx10012utf2',
                     'koreaneuc.utf2ksx10011',
                     'koreaneuc.utf2ksx10012',
                     'ksc5601_kr',
                     'koreanksc.__init__',
                     'koreanksc.ksc56012utf1',
                     'koreanksc.ksc56012utf2',
                     'koreanksc.ksc56012utf3',
                     'koreanksc.utf2ksc56011',
                     'koreanksc.utf2ksc56012',
                     'koreanksc.utf2ksc56013'])

