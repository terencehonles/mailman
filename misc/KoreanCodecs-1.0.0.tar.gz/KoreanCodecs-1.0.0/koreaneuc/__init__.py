# Chen Chien-Hsun, modified from Tamito KAJIYAMA's original code
