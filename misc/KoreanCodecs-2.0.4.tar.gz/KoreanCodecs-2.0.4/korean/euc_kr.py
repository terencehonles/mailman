# Hye-Shik Chang <16 Feb 2002>
# $Id: euc_kr.py,v 1.1.1.1 2002/02/16 00:51:13 perky Exp $

try:
    from korean.c.euc_kr import *
except ImportError:
    from korean.python.euc_kr import *
