# Hye-Shik Chang <16 Feb 2002>
# $Id: johab.py,v 1.1.1.1 2002/02/16 00:51:13 perky Exp $

try:
    from korean.c.johab import *
except ImportError:
    from korean.python.johab import *
