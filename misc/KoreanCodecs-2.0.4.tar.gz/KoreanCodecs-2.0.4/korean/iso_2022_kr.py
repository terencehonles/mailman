# Hye-Shik Chang <16 Feb 2002>
# $Id: iso_2022_kr.py,v 1.1.1.1 2002/02/16 00:51:13 perky Exp $

try:
    from korean.c.iso_2022_kr import *
except ImportError:
    from korean.python.iso_2022_kr import *
