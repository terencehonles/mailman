# Hye-Shik Chang <16 Feb 2002>
# $Id: cp949.py,v 1.1.1.1 2002/02/16 00:51:13 perky Exp $

try:
    from korean.c.cp949 import *
except ImportError:
    from korean.python.cp949 import *
