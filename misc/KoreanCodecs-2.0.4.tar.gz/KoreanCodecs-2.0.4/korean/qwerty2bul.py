# Hye-Shik Chang <16 Feb 2002>
# $Id: qwerty2bul.py,v 1.1.1.1 2002/02/16 00:51:13 perky Exp $

try:
    from korean.c.qwerty2bul import *
except ImportError:
    from korean.python.qwerty2bul import *
