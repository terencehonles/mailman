# Hye-Shik Chang <16 Feb 2002>
# $Id: unijohab.py,v 1.1 2002/02/16 11:34:25 perky Exp $

try:
    from korean.c.unijohab import *
except ImportError:
    from korean.python.unijohab import *
