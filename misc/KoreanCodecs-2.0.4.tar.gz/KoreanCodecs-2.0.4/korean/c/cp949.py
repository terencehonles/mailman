# Hye-Shik Chang <16 Mar 2002>
#
# $Id: cp949.py,v 1.2 2002/04/28 08:02:31 perky Exp $

import codecs
import _koco

class Codec(codecs.Codec):
    encode = _koco.cp949_encode
    decode = _koco.cp949_decode

class StreamWriter(Codec, codecs.StreamWriter):
    pass

class StreamReader(Codec, _koco.StreamReader, codecs.StreamReader):
    encoding = 'cp949'

### encodings module API

def getregentry():
    return (Codec().encode,Codec().decode,StreamReader,StreamWriter)
