# Hye-Shik Chang <15 Mar 2002>
#
# $Id: euc_kr.py,v 1.2 2002/04/28 06:54:11 perky Exp $

import codecs
import _koco

class Codec(codecs.Codec):
    encode = _koco.euc_kr_encode
    decode = _koco.euc_kr_decode

class StreamWriter(Codec, codecs.StreamWriter):
    pass

class StreamReader(Codec, _koco.StreamReader, codecs.StreamReader):
    encoding = 'euc-kr'

### encodings module API

def getregentry():
    return (Codec().encode,Codec().decode,StreamReader,StreamWriter)
