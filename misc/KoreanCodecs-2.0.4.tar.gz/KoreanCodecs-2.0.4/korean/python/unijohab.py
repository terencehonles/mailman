# Hye-Shik Chang <16 Feb 2002>
# $Id: unijohab.py,v 1.4 2002/04/24 07:38:11 perky Exp $

import codecs
from korean.hangul import ishangul, disjoint, conjoin

class Codec(codecs.Codec):

    # Unicode to character buffer
    def encode(self, data, errors='strict',
               supported_errors=('strict', 'ignore', 'replace')):

        if errors not in supported_errors:
            raise UnicodeError, "unknown error handling"

        return disjoint(data).encode('utf-8', errors), len(data)

    # character buffer to Unicode
    def decode(self, data, errors='strict',
               supported_errors=('strict', 'ignore', 'replace')):

        if errors not in supported_errors:
            raise UnicodeError, "unknown error handling"

        return conjoin(unicode(data, 'utf-8', errors)), len(data)

class StreamWriter(Codec, codecs.StreamWriter):
    pass

class StreamReader(Codec, codecs.StreamReader):
    pass
    # XXX: Temporarily None.

### encodings module API

def getregentry():
    return (Codec().encode,Codec().decode,StreamReader,StreamWriter)
