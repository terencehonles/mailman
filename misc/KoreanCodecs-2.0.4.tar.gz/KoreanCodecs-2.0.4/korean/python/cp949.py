# Hye-Shik Chang <16 Feb 2002>
# originally written by Tamito KAJIYAMA
#
# $Id: cp949.py,v 1.2 2002/03/16 02:35:20 perky Exp $

from korean.python.euc_kr import *

from korean.mappings import uhc
encmap_hangul.update(uhc.encoding_map)
decmap_hangul.update(uhc.decoding_map)
del uhc
