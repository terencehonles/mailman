try:
    from korean.c.hangul import *
except:
    from korean.python.hangul import *
