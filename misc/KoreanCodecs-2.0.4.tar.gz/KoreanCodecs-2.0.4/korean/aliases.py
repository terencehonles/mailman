# Hye-Shik Chang <17 Apr 2002>
# $Id: aliases.py,v 1.4 2002/04/26 11:39:35 perky Exp $

import encodings.aliases

encodings.aliases.aliases.update({
    'cp949':        'korean.cp949',
    'ms949':        'korean.cp949',
    'uhc':          'korean.cp949',
    'euc_kr':       'korean.euc_kr',
    'euckr':        'korean.euc_kr',
    'ksc5601':      'korean.euc_kr',
    'ksc5601_1987': 'korean.euc_kr',
    'ksc_5601_1987':'korean.euc_kr',
    'ks_c_5601_1987':'korean.euc_kr',
    'ksx1001':      'korean.euc_kr',
    'iso_2022_kr':  'korean.iso_2022_kr',
    'iso2022kr':    'korean.iso_2022_kr',
    'iso2022_kr':   'korean.iso_2022_kr',
    'johab':        'korean.johab',
    'qwerty2bul':   'korean.qwerty2bul',
    'unijohab':     'korean.unijohab',
    'macjohab':     'korean.unijohab',
})
