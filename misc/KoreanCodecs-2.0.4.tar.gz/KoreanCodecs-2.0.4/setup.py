#!/usr/bin/env python
# $Id: setup.py,v 1.24 2002/04/30 01:05:15 perky Exp $

import sys
from distutils.core import setup, Extension
from distutils.command.install import install

flavors = {
    'aliases': 1,
    'extension': 1,
}
for flname in flavors.keys():
    if '--without-'+flname in sys.argv:
        sys.argv.remove('--without-'+flname)
        flavors[flname] = 0
    if '--with-'+flname in sys.argv:
        sys.argv.remove('--with-'+flname)
        flavors[flname] = 1

class Install(install):
    def initialize_options (self):
        install.initialize_options(self)
        if flavors['aliases']:
            if sys.hexversion >= 0x2010000:
                self.extra_path = ("korean", "import korean.aliases")
            else:
                self.extra_path = "korean"
    def finalize_options (self):
        org_install_lib = self.install_lib
        install.finalize_options(self)
        self.install_libbase = self.install_lib = \
            org_install_lib or self.install_purelib

setup (name = "KoreanCodecs",
       version = "2.0.4",
       description = "Korean Codecs for Python Unicode Support",
       long_description = "This package provides Unicode codecs that "
            "make Python aware of Korean character encodings such as "
            "EUC-KR, CP949 and ISO-2022-KR. By using this package, "
            "Korean characters can be treated as a character string "
            "instead of a byte sequence.",
       author = "Hye-Shik Chang",
       author_email = "perky@fallin.lv",
       license = "LGPL",
       url = "http://sourceforge.net/projects/koco",
       cmdclass = {'install': Install},
       packages = ['korean',
                   'korean.mappings',
                   'korean.c',
                   'korean.python'],
       ext_modules = flavors['extension'] and [
           Extension("korean.c._koco", ["src/_koco.c"]),
           Extension("korean.c.hangul", ["src/hangul.c"]),
       ] or [])
