#! /usr/bin/env python
#
# Copyright (C) 2001 Python Software Foundation

# Standard distutils setup.py install script for the `mimelib' library, a next
# generation MIME library for Python.  To install into your existing Python
# distribution, run the following at the command line:
#
# % python setup.py install

from distutils.core import setup

setup(name='email',
      version='0.91',
      description='Next generation MIME library',
      author='Barry Warsaw',
      author_email='barry@zope.com',
      url='http://sf.net/projects/mimelib',
      packages=['email'],
      )
