# Tamito KAJIYAMA <13 December 2000>

from japanese.shift_jis import *
