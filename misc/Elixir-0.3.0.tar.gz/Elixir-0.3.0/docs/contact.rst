=======
Contact
=======

For any question, suggestion, comment, bugreport or patch you might have, 
please send it to the `mailing list <http://groups.google.com/group/sqlelixir/topics>`_.

.. I would have liked to include a form to subscribe directly to the group
.. but it doesn't seem to be possible to do forms with rst.

.. <table class="subscribe">
..  <form action="http://groups.google.com/group/sqlelixir/boxsubscribe">
.. 	    <tr><th colspan="2">Subscribe to the list !</th></tr>
..      <tr> 
..          <td>Email: <input type=text name=email></td>
..          <td>
..              <input type=submit name="sub" value="Subscribe">
..          </td>
..       </tr>
..  </form>
.. </table>

=======
Authors
=======

If you would like to contact the authors directly:

Daniel Haus 
    http://www.danielhaus.de

Gaëtan de Menten 
    http://openhex.com

Jonathan LaCour 
    http://cleverdevil.org
