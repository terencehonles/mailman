==========
Get Elixir
==========

Easy installation
-----------------
         
You can install the Elixir package by simply typing [#]_:
 
 ::
 
     easy_install Elixir
 
 .. [#] If you don't have "``easy_install``" yet, please visit the
        `EasyInstall website
        <http://peak.telecommunity.com/DevCenter/EasyInstall>`_ first and find
        out how to use it (it's pretty easy, like the name promises).


Releases
--------

Each release is also available for standard download on the `Cheese Shop
<http://cheeseshop.python.org/pypi/Elixir/>`_

Development Version
-------------------

The latest development version is available via subversion:

svn checkout http://elixir.ematia.de/svn/elixir/trunk/ elixir

License
-------

Elixir is covered by the MIT license.

