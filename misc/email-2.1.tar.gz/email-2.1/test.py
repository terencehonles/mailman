# Copyright (C) 2002 Python Software Foundation

"""A simple test runner, which sets up sys.path properly."""

import sys
import os
import unittest

sys.path[0:0] = ['email', 'test']

import test_support
import test_email
try:
    # This will raise a TestSkipped if the Japanese codecs aren't installed
    import test_email_codecs
except test_support.TestSkipped:
    test_email_codecs = None

def suite():
    suite = unittest.TestSuite()
    suite.addTest(test_email.suite())
    if test_email_codecs is not None:
        suite.addTest(test_email_codecs.suite())
    return suite

unittest.main(defaultTest='suite')
