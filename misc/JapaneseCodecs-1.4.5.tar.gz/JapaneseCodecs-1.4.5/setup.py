#!/usr/bin/env python
# Tamito KAJIYAMA <30 November 2000>
# $Id: setup.py,v 1.7 2002/04/17 03:53:31 kajiyama Exp $

from distutils.core import setup, Extension
from distutils.command.build_py import build_py
from distutils.command.install import install

class Build_py(build_py):
    user_options = build_py.user_options + [
        ('with-aliases', None, "register aliases [default]"),
        ("without-aliases", None, "don't register aliases"),
        ]
    boolean_options = build_py.boolean_options + [
        "with-aliases", "without-aliases",
        ]
    negative_opt = {"without-aliases": "with-aliases"}
    def initialize_options (self):
        build_py.initialize_options(self)
        self.with_aliases = 1
    def finalize_options (self):
        build_py.finalize_options(self)
        if self.with_aliases:
            self.packages.append('japanese.aliases')

class Install(install):
    def finalize_options (self):
        install.finalize_options(self)
        self.distribution.data_files = [
            (self.install_purelib, ["japanese.pth"])]

setup (name = "JapaneseCodecs",
       version = "1.4.5",
       description = "Japanese Codecs for Python Unicode Support",
       author = "Tamito KAJIYAMA",
       author_email = "kajiyama@grad.sccs.chukyo-u.ac.jp",
       url = "http://pseudo.grad.sccs.chukyo-u.ac.jp/~kajiyama/python/",
       cmdclass = {'build_py': Build_py, 'install': Install},
       packages = ['japanese',
                   'japanese.python',
                   'japanese.c',
                   'japanese.mappings'],
       ext_modules = [
           Extension("japanese.c._japanese_codecs",
                     ["src/_japanese_codecs.c"])])
