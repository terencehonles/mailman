#!/usr/bin/env python
# Tamito KAJIYAMA <30 November 2000>

from distutils.core import setup, Extension

setup (name = "JapaneseCodecs",
       version = "1.4.3",
       description = "Japanese Codecs for Python Unicode Support",
       author = "Tamito KAJIYAMA",
       author_email = "kajiyama@grad.sccs.chukyo-u.ac.jp",
       url = "http://pseudo.grad.sccs.chukyo-u.ac.jp/~kajiyama/python/",
       packages = ['japanese',
                   'japanese.python',
                   'japanese.c',
                   'japanese.mappings'],
       ext_modules = [
           Extension("japanese.c._japanese_codecs",
                     ["src/_japanese_codecs.c"])])
